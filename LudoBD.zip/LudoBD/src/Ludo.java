///God is Almighty
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;

public class Ludo extends JFrame {
	
	static int i1=0, i2=0;
	static JFrame frame ;
	
	static JLabel label1 ,label2 ,label3,label4, pic,picA,picB,picC,picD;
	
	static JLabel Lx;
	
	static JButton[] road;
	static JButton[] gutiP1,gutiP2,gutiP3,gutiP4;
	static JButton Click;
	//static JButton[] gutiP2;
	JPanel panel;
	JButton play1,play2,play3,play4;
	//JButton play2;
	static String str111 ,str222,str333,str444, chk="A";
	//static String str222;
	static int chal1 = 0;
	public static int temp=0;
	static ImageIcon red1 =new ImageIcon("src\\red1.png");
	static ImageIcon r1r2 = new ImageIcon("src\\OT.png");
	static ImageIcon red2 =new ImageIcon("src\\red2.png");
	static ImageIcon red3 =new ImageIcon("src\\red3.png");
	static ImageIcon red4 =new ImageIcon("src\\red4.png");
	
	static ImageIcon LudoMaster = new ImageIcon("src\\LudoMaster.png");
	
	
	static ImageIcon dice1 = new ImageIcon("src\\dice1.png");
	static ImageIcon dice2 = new ImageIcon("src\\dice2.png");
	static ImageIcon dice3 = new ImageIcon("src\\dice3.png");
	static ImageIcon dice4 = new ImageIcon("src\\dice4.png");
	static ImageIcon dice5 = new ImageIcon("src\\dice5.png");
	static ImageIcon dice6 = new ImageIcon("src\\dice6.png");
	
	static ImageIcon green1 =new ImageIcon("src\\green1.png");
	static ImageIcon green2 =new ImageIcon("src\\green2.png");
	static ImageIcon green3 =new ImageIcon("src\\green3.png");
	static ImageIcon green4 =new ImageIcon("src\\green4.png");
	static ImageIcon g =new ImageIcon("");
	
	static ImageIcon gA =new ImageIcon("src\\newA.png");
	static ImageIcon gB =new ImageIcon("src\\gBjpg.jpg");
	
	
	static int activeguti1=0 , desti1 , getguti , dif ,age, m1=0,m2=0,m3=0,m4=0 , ZZ1=0 , ZZ2=0 , ZZ3=0, ZZ4=0;
	static int activeguti2=0;
	static int whoActive;
	
	static int P1pos1=0,jhamela1=0;
	static int P1pos2=0,jhamela2=0;
	static int P1pos3=0,jhamela3=0;
	static int P1pos4=0,jhamela4=0;
	
	static int gutiP1active1=0;
	static int gutiP1active2=0;
	static int gutiP1active3=0;
	static int gutiP1active4=0;
	
	static int gutiP2active1=0;
	static int gutiP2active2=0;
	static int gutiP2active3=0;
	static int gutiP2active4=0;
	
	static int P2pos1=26,khamela1=0;
	static int P2pos2=26,khamela2=0;
	static int P2pos3=26,khamela3=0;
	static int P2pos4=26,khamela4=0;
	static int selectGuti=0;
	static int sixCounting=0;
	static int dice , pp , cnt=0;
	static int P1dice[] = new int[7];
	static int P2dice[] = new int[7];
	static int checkRoad[] = new int[100];
	public Ludo()

	{
		
		//Lx = new Jlabel(gA);
		
		pic = new JLabel(g);
		
		picA = new JLabel(gA);
		picB = new JLabel(gB);
		
		picC = new JLabel(LudoMaster);
		
		
		road = new JButton[100];
		
		gutiP1 = new JButton[5];
		gutiP2 = new JButton[5];
		gutiP3 = new JButton[5];
		gutiP4 = new JButton[5];
		
		for(int i=1; i<=6; i++)
		{
			P1dice[i]=0;
			P2dice[i]=0;
		}
		
	    initial();
	   
		play1.addActionListener(new ActionListener()
				{
			      public void actionPerformed(ActionEvent e)
			        {
				       PlayMethod1();
			        }
				}	
		);
		
		
		
		play2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				PlayMethod2();
			}
		}	
		);
		
		
		
		
		play3.addActionListener(new ActionListener()
		{
	      public void actionPerformed(ActionEvent e)
	        {
		       PlayMethod3();
	        }
		}	
        );

       play4.addActionListener(new ActionListener()
       {
	     public void actionPerformed(ActionEvent e)
	     {
		   PlayMethod4();
	     }
       }	
      );
		
		
		
		
		
		
		
		
	}

	//***Start PlayMethod1()***\\
	
	
	
	public static void PlayMethod1()
	{
		Random ran= new Random();
		dice = 1 + ran.nextInt(6);
	   if(dice==6) //activeguti1++;
		   sixCounting++;
		str111= "Palyer A : " + String.valueOf(dice);
		label1.setText(str111);
		
		if(dice==1)
			pic.setIcon(dice1);
		if(dice==2)
			pic.setIcon(dice2);
		if(dice==3)
			pic.setIcon(dice3);
		if(dice==4)
			pic.setIcon(dice4);
		if(dice==5)
			pic.setIcon(dice5);
		if(dice==6)
			pic.setIcon(dice6);
	
			if(dice==6 ){
				//road[32].setIcon(r1r2);
				JOptionPane.showMessageDialog(null,"Select Guti to active if need");

					gutiP1[1].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
							if(gutiP1active1==0){
							gutiP1[1].setIcon(red1);
							gutiP1active1=1;
					
							}
						}
						});
					gutiP1[2].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
							if(gutiP1active2==0){
							gutiP1[2].setIcon(red2);
							
							gutiP1active2=1;
							}
						}
						});
					gutiP1[3].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
							if(gutiP1active3==0){
							gutiP1[3].setIcon(red3);
							//getGuti(3);
							gutiP1active3=1;
							
							}
						}
						});
					gutiP1[4].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{   
							if(gutiP1active4==0){
							gutiP1[4].setIcon(red4);
							gutiP1active4=1;
							
						    }
						}
						});
				
			}
			////
			else {
			if(gutiP1active1==1 && jhamela1==0) {
		
				gutiP1[1].addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent clicking)
					{
					
							
						//P1pos1+=dice;
						gutiP1[1].setIcon(null); 
						gutiP1[1].setBackground(Color.orange);
						//System.out.println("Orange");
						jhamela1=1;
						P1pos1+=dice;
						//jhamela1=1;
						if(P1pos1==51) P1pos1=52;
						System.out.println("Red 1 =" +P1pos1);
						if(P1pos1<57){
							road[P1pos1].setIcon(red1);
							if(P1pos1-dice==51) road[50].setIcon(null);
							road[P1pos1-dice].setIcon(null);
							
							}
							
							if(P1pos1==57){
								System.out.println("Red 1 Ghore Uthegeche");
								gutiP1active1=100;
								//road[P1pos1-dice].setIcon(null);
								//road[P1pos1-dice].setIcon(null);
								gutiP1[1].setIcon(null);
								gutiP1[1].setBackground(Color.black);
								if(P1pos1-dice==51) road[50].setIcon(null);
							road[P1pos1-dice].setIcon(null);
							}
				
						
					}
					
				}
			
				); //GutiPlay1Active method closed
			
				//continue;
		
			} // if(gutiP1active1==1)   closed  
			
			if(gutiP1active2==1 && jhamela2==0) {
				
				gutiP1[2].addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent clicking)
					{
					
							
						//P1pos1+=dice;
						gutiP1[2].setIcon(null); 
						gutiP1[2].setBackground(Color.orange);
						System.out.println("Orange");
						jhamela2=1;
						P1pos2+=dice;
						//jhamela1=1;
						if(P1pos2==51) P1pos2=52;
						System.out.println("Red 2 ="+P1pos2);
						if(P1pos2<57){
							road[P1pos2].setIcon(red2);
							if(P1pos2-dice==51) road[50].setIcon(null);
							road[P1pos2-dice].setIcon(null);
							
							}
							
							if(P1pos2==57){
								System.out.println("Red 2 Ghore Uthegeche");
								gutiP1active2=100;
								//road[P1pos1-dice].setIcon(null);
								//road[P1pos1-dice].setIcon(null);
								gutiP1[2].setIcon(null);
								gutiP1[2].setBackground(Color.black);
								if(P1pos2-dice==51) road[50].setIcon(null);
							road[P1pos2-dice].setIcon(null);
							}
				
						
					}
					
				}
			
				); 
		
			}// red 2 er jonno closed
			
			if(gutiP1active3==1 && jhamela3==0) {
				
				gutiP1[3].addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent clicking)
					{
					
						gutiP1[3].setIcon(null); 
						gutiP1[3].setBackground(Color.orange);
						//System.out.println("Orange");
						jhamela3=1;
						P1pos3+=dice;
						//jhamela1=1;
						if(P1pos3==51) P1pos3=52;
						System.out.println("Red 3 = "+P1pos3);
						if(P1pos3<57){
							road[P1pos3].setIcon(red3);
							if(P1pos3-dice==51) road[50].setIcon(null);
							road[P1pos3-dice].setIcon(null);
							
							}
							
							if(P1pos3==57){
								System.out.println("Red 3 Ghore Uthegeche");
								gutiP1active3=100;
								
								gutiP1[3].setIcon(null);
								gutiP1[3].setBackground(Color.black);
								if(P1pos3-dice==51) road[50].setIcon(null);
							road[P1pos3-dice].setIcon(null);
							}
				
						
					}
					
				}
			
				); 
			
				//continue;
		
			} // Red 3 er jonno closed
			
			
			if(gutiP1active4==1 && jhamela4==0) {
				
				gutiP1[4].addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent clicking)
					{
					
							
						//P1pos1+=dice;
						gutiP1[4].setIcon(null); 
						gutiP1[4].setBackground(Color.orange);
						//System.out.println("Orange");
						jhamela4=1;
						P1pos4+=dice;
						//jhamela1=1;
						if(P1pos4==51) P1pos4=52;
						System.out.println("Red 4 ="+P1pos4);
						if(P1pos4<57){
							road[P1pos4].setIcon(red4);
							if(P1pos4-dice==51) road[50].setIcon(null);
							road[P1pos4-dice].setIcon(null);
							
							}
							
							if(P1pos4==57){
								System.out.println("Red 4 Ghore Uthegeche");
								gutiP1active4=100;
								//road[P1pos1-dice].setIcon(null);
								//road[P1pos1-dice].setIcon(null);
								gutiP1[4].setIcon(null);
								gutiP1[4].setBackground(Color.black);
								if(P1pos4-dice==51) road[50].setIcon(null);
							road[P1pos4-dice].setIcon(null);
							}
				
						
					}
					
				}
			
				); 
			
				
		
			}// Red 4 er jonno closed
						
          } // else closed
	} 
	
		
	///**** Closed PlayMethod1()****\\\
	
	
	
	
	
	///**** Start PlayMethod2()*****\\\
	
	
	public static void PlayMethod2()
	{
		Random ran= new Random();
		dice = 1 + ran.nextInt(6);
		str222= "Palyer B : " + String.valueOf(dice);
		label2.setText(str222);
		
		if(dice==1)
			pic.setIcon(dice1);
		if(dice==2)
			pic.setIcon(dice2);
		if(dice==3)
			pic.setIcon(dice3);
		if(dice==4)
			pic.setIcon(dice4);
		if(dice==5)
			pic.setIcon(dice5);
		if(dice==6)
			pic.setIcon(dice6);
		
		System.out.println("-----");
			if(dice==6 && activeguti2<4){
				JOptionPane.showMessageDialog(null, "You can Select Guti to active ");
				//System.out.println("dice value = "+j);
				System.out.println( "Select a Guti to active ");
				
					gutiP2[1].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
							if(gutiP2active1==0){
							gutiP2[1].setIcon(green1);
							gutiP2active1=1;
							//getGuti(1);
								cnt=1;
								activeguti2++;
							}
						}
						});
					gutiP2[2].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
							if(gutiP2active2==0){
							gutiP2[2].setIcon(green2);
							//getGuti(2);
							gutiP2active2=1;
							cnt=1;
							activeguti2++;
							}
						}
						});
					gutiP2[3].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
							if(gutiP2active3==0){
							gutiP2[3].setIcon(green3);
							//getGuti(3);
							gutiP2active3=1;
							cnt=1;
							activeguti2++;
							}
						}
						});
					gutiP2[4].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{if(gutiP2active4==0){
							gutiP2[4].setIcon(green4);
							//getGuti(4);
							gutiP2active4=1;
							cnt=1;
							activeguti2++;
						}
						}
						});
					
					System.out.println( "Total = "+activeguti2);
			}
			else{	
				/////******(1)***********\\\\\\\		
				if(gutiP2active1==1 && khamela1==0) {
					
					gutiP2[1].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
						
								System.out.println("---->>>>>"+gutiP2active1);
								age=P2pos1;
								khamela1=1;
								P2pos1+=dice;
								if(P2pos1>=67){
									gutiP2active1=100;
									road[age].setIcon(null);
									gutiP2[1].setIcon(null);
									gutiP2[1].setBackground(Color.black);
								}
								
								if(P2pos1>51 && ZZ1==0){
									dif=P2pos1-51-1;
									P2pos1=dif;
									road[P2pos1].setIcon(green1);
									road[age].setIcon(null);
									m1=1; ZZ1=1; 
								}
								else if(P2pos1>24 && m1==1)
								{
									
									dif=P2pos1-24;
									P2pos1=61+dif;
									//System.out.println(m+"----->"+P2pos1+"..........."+age);
									m1=0;
								}
								
								//System.out.println(m+"........"+P2pos1+"..........."+age);
								road[P2pos1].setIcon(green1);
								if(P2pos1>56){
									//road[P2pos1].setIcon(green1);
									road[age].setIcon(null);
								}
								road[P2pos1-dice].setIcon(null);
								checkRoad[P2pos1]=1;
								checkRoad[P2pos1-dice]=0;
							}
					}
				); ///  End of ActionPerformed
							
							
				} // if closer
				
				
				/*\\\\*****(1)End******\\\\\\\*////*\
				
				//|***** (2)Start*****/////\\\
				
				
				
		if(gutiP2active2==1 && khamela2==0) {
					
					gutiP2[2].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
						
								System.out.println("---->>>>>"+gutiP2active1);
								age=P2pos2;
								 khamela2=1;
								P2pos2+=dice;
								if(P2pos2==67){
									gutiP2active2=100;
									road[age].setIcon(null);
									gutiP2[2].setIcon(null);
									gutiP2[2].setBackground(Color.black);
								}
								
								if(P2pos2>51 && ZZ2==0){
									dif=P2pos2-51-1;
									P2pos2=dif;
									road[P2pos2].setIcon(green2);
									road[age].setIcon(null);
									m2=1; ZZ2=1; 
								}
								else if(P2pos2>24 && m2==1)
								{
									
									dif=P2pos2-24;
									P2pos2=61+dif;
									//System.out.println(m+"----->"+P2pos1+"..........."+age);
									m2=0;
								}
								
								//System.out.println(m+"........"+P2pos1+"..........."+age);
								road[P2pos2].setIcon(green2);
								if(P2pos2>56){
									//road[P2pos1].setIcon(green1);
									road[age].setIcon(null);
								}
								road[P2pos2-dice].setIcon(null);
								checkRoad[P2pos2]=1;
								checkRoad[P2pos2-dice]=0;
							}
					}
				); ///  End of ActionListener
							
							
				} // (2) sesh
				
			//********(2) End********////
				
		
		     //******(3) Start********////
		
		
		if(gutiP2active3==1 && khamela3==0) {
			
			gutiP2[3].addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent clicking)
				{
				
						System.out.println("---->>>>>"+gutiP2active1);
						age=P2pos3;
						khamela3=1;
						P2pos3+=dice;
						if(P2pos3==67){
							gutiP2active3=100;
							road[age].setIcon(null);
							gutiP2[3].setIcon(null);
							gutiP2[3].setBackground(Color.black);
						}
						
						if(P2pos3>51 && ZZ3==0){
							dif=P2pos3-51-1;
							P2pos3=dif;
							road[P2pos3].setIcon(green3);
							road[age].setIcon(null);
							m3=1; ZZ3=1; 
						}
						else if(P2pos3>24 && m3==1)
						{
							
							dif=P2pos3-24;
							P2pos3=61+dif;
							//System.out.println(m+"----->"+P2pos1+"..........."+age);
							m3=0;
						}
						
						//System.out.println(m+"........"+P2pos1+"..........."+age);
						road[P2pos3].setIcon(green3);
						if(P2pos3>56){
							//road[P2pos1].setIcon(green3);
							road[age].setIcon(null);
						}
						road[P2pos3-dice].setIcon(null);
						checkRoad[P2pos3]=1;
						checkRoad[P2pos3-dice]=0;
					}
			}
		); ///  End of ActionPerformed
					
					
		}   //(3) sesh
			
		
		
		///*****(3)End*******////
		
		
		 /////****(4)****Start****////
		
		if(gutiP2active4==1 && khamela4==0) {
			
			gutiP2[4].addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent clicking)
				{
				
						System.out.println("---->>>>>"+gutiP2active1);
						age=P2pos4;
						khamela4=1;
						P2pos4+=dice;
						if(P2pos4==67){
							gutiP2active1=100;
							road[age].setIcon(null);
							gutiP2[4].setIcon(null);
							gutiP2[4].setBackground(Color.black);
						}
						
						if(P2pos4>51 && ZZ4==0){
							dif=P2pos4-51-1;
							P2pos4=dif;
							road[P2pos4].setIcon(green4);
							road[age].setIcon(null);
							m4=1; ZZ4=1; 
						}
						else if(P2pos4>24 && m4==1)
						{
							
							dif=P2pos4-24;
							P2pos4=61+dif;
							//System.out.println(m+"----->"+P2pos1+"..........."+age);
							m4=0;
						}
						
						//System.out.println(m+"........"+P2pos1+"..........."+age);
						road[P2pos4].setIcon(green4);
						if(P2pos4>56){
							//road[P2pos1].setIcon(green1);
							road[age].setIcon(null);
						}
						road[P2pos4-dice].setIcon(null);
						checkRoad[P2pos4]=1;
						checkRoad[P2pos4-dice]=0;
					}
			}
		); ///  End of ActionPerformed
					
					
		}  //(4) sesh
		
		///*****(4)***End****/////
				
				
				
				
				
			}  // ******* else  condition closer*********
			
			
	}   //End of PlayMethod2()
		
	//System.out.println("------------------------------------");
	
				
			
			
			
		
	
	//*** Closed PlayMethod2()***\
	
	
	
	
	
	//***Start PlayMethod3()***\\
	
	
	
		public static void PlayMethod3()
		{
			Random ran= new Random();
			dice = 1 + ran.nextInt(6);
		   if(dice==6) //activeguti1++;
			   sixCounting++;
			str333= "Palyer C : " + String.valueOf(dice);
			label3.setText(str333);
			
			if(dice==1)
				pic.setIcon(dice1);
			if(dice==2)
				pic.setIcon(dice2);
			if(dice==3)
				pic.setIcon(dice3);
			if(dice==4)
				pic.setIcon(dice4);
			if(dice==5)
				pic.setIcon(dice5);
			if(dice==6)
				pic.setIcon(dice6);
		
				if(dice==6 ){
					//road[32].setIcon(r1r2);
					JOptionPane.showMessageDialog(null,"Select Guti to active if need");

						gutiP1[1].addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent clicking)
							{
								if(gutiP1active1==0){
								gutiP1[1].setIcon(red1);
								gutiP1active1=1;
						
								}
							}
							});
						gutiP1[2].addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent clicking)
							{
								if(gutiP1active2==0){
								gutiP1[2].setIcon(red2);
								
								gutiP1active2=1;
								}
							}
							});
						gutiP1[3].addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent clicking)
							{
								if(gutiP1active3==0){
								gutiP1[3].setIcon(red3);
								//getGuti(3);
								gutiP1active3=1;
								
								}
							}
							});
						gutiP1[4].addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent clicking)
							{   
								if(gutiP1active4==0){
								gutiP1[4].setIcon(red4);
								gutiP1active4=1;
								
							    }
							}
							});
					
				}
				////
				else {
				if(gutiP1active1==1 && jhamela1==0) {
			
					gutiP1[1].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
						
								
							//P1pos1+=dice;
							gutiP1[1].setIcon(null); 
							gutiP1[1].setBackground(Color.orange);
							//System.out.println("Orange");
							jhamela1=1;
							P1pos1+=dice;
							//jhamela1=1;
							if(P1pos1==51) P1pos1=52;
							System.out.println("Red 1 =" +P1pos1);
							if(P1pos1<57){
								road[P1pos1].setIcon(red1);
								if(P1pos1-dice==51) road[50].setIcon(null);
								road[P1pos1-dice].setIcon(null);
								
								}
								
								if(P1pos1==57){
									System.out.println("Red 1 Ghore Uthegeche");
									gutiP1active1=100;
									//road[P1pos1-dice].setIcon(null);
									//road[P1pos1-dice].setIcon(null);
									gutiP1[1].setIcon(null);
									gutiP1[1].setBackground(Color.black);
									if(P1pos1-dice==51) road[50].setIcon(null);
								road[P1pos1-dice].setIcon(null);
								}
					
							
						}
						
					}
				
					); //GutiPlay1Active method closed
				
					//continue;
			
				} // if(gutiP1active1==1)   closed  
				
				if(gutiP1active2==1 && jhamela2==0) {
					
					gutiP1[2].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
						
								
							//P1pos1+=dice;
							gutiP1[2].setIcon(null); 
							gutiP1[2].setBackground(Color.orange);
							System.out.println("Orange");
							jhamela2=1;
							P1pos2+=dice;
							//jhamela1=1;
							if(P1pos2==51) P1pos2=52;
							System.out.println("Red 2 ="+P1pos2);
							if(P1pos2<57){
								road[P1pos2].setIcon(red2);
								if(P1pos2-dice==51) road[50].setIcon(null);
								road[P1pos2-dice].setIcon(null);
								
								}
								
								if(P1pos2==57){
									System.out.println("Red 2 Ghore Uthegeche");
									gutiP1active2=100;
									//road[P1pos1-dice].setIcon(null);
									//road[P1pos1-dice].setIcon(null);
									gutiP1[2].setIcon(null);
									gutiP1[2].setBackground(Color.black);
									if(P1pos2-dice==51) road[50].setIcon(null);
								road[P1pos2-dice].setIcon(null);
								}
					
							
						}
						
					}
				
					); 
			
				}// red 2 er jonno closed
				
				if(gutiP1active3==1 && jhamela3==0) {
					
					gutiP1[3].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
						
							gutiP1[3].setIcon(null); 
							gutiP1[3].setBackground(Color.orange);
							//System.out.println("Orange");
							jhamela3=1;
							P1pos3+=dice;
							//jhamela1=1;
							if(P1pos3==51) P1pos3=52;
							System.out.println("Red 3 = "+P1pos3);
							if(P1pos3<57){
								road[P1pos3].setIcon(red3);
								if(P1pos3-dice==51) road[50].setIcon(null);
								road[P1pos3-dice].setIcon(null);
								
								}
								
								if(P1pos3==57){
									System.out.println("Red 3 Ghore Uthegeche");
									gutiP1active3=100;
									
									gutiP1[3].setIcon(null);
									gutiP1[3].setBackground(Color.black);
									if(P1pos3-dice==51) road[50].setIcon(null);
								road[P1pos3-dice].setIcon(null);
								}
					
							
						}
						
					}
				
					); 
				
					//continue;
			
				} // Red 3 er jonno closed
				
				
				if(gutiP1active4==1 && jhamela4==0) {
					
					gutiP1[4].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
						
								
							//P1pos1+=dice;
							gutiP1[4].setIcon(null); 
							gutiP1[4].setBackground(Color.orange);
							//System.out.println("Orange");
							jhamela4=1;
							P1pos4+=dice;
							//jhamela1=1;
							if(P1pos4==51) P1pos4=52;
							System.out.println("Red 4 ="+P1pos4);
							if(P1pos4<57){
								road[P1pos4].setIcon(red4);
								if(P1pos4-dice==51) road[50].setIcon(null);
								road[P1pos4-dice].setIcon(null);
								
								}
								
								if(P1pos4==57){
									System.out.println("Red 4 Ghore Uthegeche");
									gutiP1active4=100;
									//road[P1pos1-dice].setIcon(null);
									//road[P1pos1-dice].setIcon(null);
									gutiP1[4].setIcon(null);
									gutiP1[4].setBackground(Color.black);
									if(P1pos4-dice==51) road[50].setIcon(null);
								road[P1pos4-dice].setIcon(null);
								}
					
							
						}
						
					}
				
					); 
				
					
			
				}// Red 4 er jonno closed
							
	          } // else closed
		} 
		
			
		///**** Closed PlayMethod3()****\\\
		
		
	
		
		
		//***Start PlayMethod1()***\\
		
		
		
		public static void PlayMethod4()
		{
			Random ran= new Random();
			dice = 1 + ran.nextInt(6);
		   if(dice==6) //activeguti1++;
			   sixCounting++;
			str444= "Palyer D : " + String.valueOf(dice);
			label4.setText(str444);
			
			if(dice==1)
				pic.setIcon(dice1);
			if(dice==2)
				pic.setIcon(dice2);
			if(dice==3)
				pic.setIcon(dice3);
			if(dice==4)
				pic.setIcon(dice4);
			if(dice==5)
				pic.setIcon(dice5);
			if(dice==6)
				pic.setIcon(dice6);
		
				if(dice==6 ){
					//road[32].setIcon(r1r2);
					JOptionPane.showMessageDialog(null,"Select Guti to active if need");

						gutiP1[1].addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent clicking)
							{
								if(gutiP1active1==0){
								gutiP1[1].setIcon(red1);
								gutiP1active1=1;
						
								}
							}
							});
						gutiP1[2].addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent clicking)
							{
								if(gutiP1active2==0){
								gutiP1[2].setIcon(red2);
								
								gutiP1active2=1;
								}
							}
							});
						gutiP1[3].addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent clicking)
							{
								if(gutiP1active3==0){
								gutiP1[3].setIcon(red3);
								//getGuti(3);
								gutiP1active3=1;
								
								}
							}
							});
						gutiP1[4].addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent clicking)
							{   
								if(gutiP1active4==0){
								gutiP1[4].setIcon(red4);
								gutiP1active4=1;
								
							    }
							}
							});
					
				}
				////
				else {
				if(gutiP1active1==1 && jhamela1==0) {
			
					gutiP1[1].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
						
								
							//P1pos1+=dice;
							gutiP1[1].setIcon(null); 
							gutiP1[1].setBackground(Color.orange);
							//System.out.println("Orange");
							jhamela1=1;
							P1pos1+=dice;
							//jhamela1=1;
							if(P1pos1==51) P1pos1=52;
							System.out.println("Red 1 =" +P1pos1);
							if(P1pos1<57){
								road[P1pos1].setIcon(red1);
								if(P1pos1-dice==51) road[50].setIcon(null);
								road[P1pos1-dice].setIcon(null);
								
								}
								
								if(P1pos1==57){
									System.out.println("Red 1 Ghore Uthegeche");
									gutiP1active1=100;
									//road[P1pos1-dice].setIcon(null);
									//road[P1pos1-dice].setIcon(null);
									gutiP1[1].setIcon(null);
									gutiP1[1].setBackground(Color.black);
									if(P1pos1-dice==51) road[50].setIcon(null);
								road[P1pos1-dice].setIcon(null);
								}
					
							
						}
						
					}
				
					); //GutiPlay1Active method closed
				
					//continue;
			
				} // if(gutiP1active1==1)   closed  
				
				if(gutiP1active2==1 && jhamela2==0) {
					
					gutiP1[2].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
						
								
							//P1pos1+=dice;
							gutiP1[2].setIcon(null); 
							gutiP1[2].setBackground(Color.orange);
							System.out.println("Orange");
							jhamela2=1;
							P1pos2+=dice;
							//jhamela1=1;
							if(P1pos2==51) P1pos2=52;
							System.out.println("Red 2 ="+P1pos2);
							if(P1pos2<57){
								road[P1pos2].setIcon(red2);
								if(P1pos2-dice==51) road[50].setIcon(null);
								road[P1pos2-dice].setIcon(null);
								
								}
								
								if(P1pos2==57){
									System.out.println("Red 2 Ghore Uthegeche");
									gutiP1active2=100;
									//road[P1pos1-dice].setIcon(null);
									//road[P1pos1-dice].setIcon(null);
									gutiP1[2].setIcon(null);
									gutiP1[2].setBackground(Color.black);
									if(P1pos2-dice==51) road[50].setIcon(null);
								road[P1pos2-dice].setIcon(null);
								}
					
							
						}
						
					}
				
					); 
			
				}// red 2 er jonno closed
				
				if(gutiP1active3==1 && jhamela3==0) {
					
					gutiP1[3].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
						
							gutiP1[3].setIcon(null); 
							gutiP1[3].setBackground(Color.orange);
							//System.out.println("Orange");
							jhamela3=1;
							P1pos3+=dice;
							//jhamela1=1;
							if(P1pos3==51) P1pos3=52;
							System.out.println("Red 3 = "+P1pos3);
							if(P1pos3<57){
								road[P1pos3].setIcon(red3);
								if(P1pos3-dice==51) road[50].setIcon(null);
								road[P1pos3-dice].setIcon(null);
								
								}
								
								if(P1pos3==57){
									System.out.println("Red 3 Ghore Uthegeche");
									gutiP1active3=100;
									
									gutiP1[3].setIcon(null);
									gutiP1[3].setBackground(Color.black);
									if(P1pos3-dice==51) road[50].setIcon(null);
								road[P1pos3-dice].setIcon(null);
								}
					
							
						}
						
					}
				
					); 
				
					//continue;
			
				} // Red 3 er jonno closed
				
				
				if(gutiP1active4==1 && jhamela4==0) {
					
					gutiP1[4].addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent clicking)
						{
						
								
							//P1pos1+=dice;
							gutiP1[4].setIcon(null); 
							gutiP1[4].setBackground(Color.orange);
							//System.out.println("Orange");
							jhamela4=1;
							P1pos4+=dice;
							//jhamela1=1;
							if(P1pos4==51) P1pos4=52;
							System.out.println("Red 4 ="+P1pos4);
							if(P1pos4<57){
								road[P1pos4].setIcon(red4);
								if(P1pos4-dice==51) road[50].setIcon(null);
								road[P1pos4-dice].setIcon(null);
								
								}
								
								if(P1pos4==57){
									System.out.println("Red 4 Ghore Uthegeche");
									gutiP1active4=100;
									//road[P1pos1-dice].setIcon(null);
									//road[P1pos1-dice].setIcon(null);
									gutiP1[4].setIcon(null);
									gutiP1[4].setBackground(Color.black);
									if(P1pos4-dice==51) road[50].setIcon(null);
								road[P1pos4-dice].setIcon(null);
								}
					
							
						}
						
					}
				
					); 
				
					
			
				}// Red 4 er jonno closed
							
	          } // else closed
		} 
		
			
		///**** Closed PlayMethod4()****\\\
		
		
		
	
	
	
	
	
	
	
	
	///****SetUp Method******\\\\\\\
	
	
	public static void setupRoad()
	{
		//gutiset1
		for(int i=1 , x=45+180; i<=4; i++ , x+=45)
		{
			gutiP1[i]=new JButton(String.valueOf(i));
			//ImageIcon pic1=new ImageIcon("src\\red1.png");
			//gutiP1[i].setIcon(null);
			gutiP1[i].setBackground(Color.white);
			gutiP1[i].setBounds(x,420,45 ,45);
			frame.getContentPane().add(gutiP1[i]);
		}
		//gutiset2
		for(int i=1 , x=630; i<=4; i++ , x+=45)
		{
			gutiP2[i]=new JButton(String.valueOf(i));
			//ImageIcon pic1=new ImageIcon("src\\red1.png");
			//gutiP2[i].setIcon(null);
			gutiP2[i].setBackground(Color.white);
			gutiP2[i].setBounds(x,200,45 ,45);
			frame.getContentPane().add(gutiP2[i]);
		}
		//gutiset3
		for(int i=1 , x=45+180; i<=4; i++ , x+=45)
		{
			gutiP3[i]=new JButton(String.valueOf(i));
			gutiP3[i].setBackground(Color.white);
			gutiP3[i].setBounds(x,200,45 ,45);
			frame.getContentPane().add(gutiP3[i]);
		}
		//gutiset4
		for(int i=1 , x=630; i<=4; i++ , x+=45)
		{
			gutiP3[i]=new JButton(String.valueOf(i));
			gutiP3[i].setBackground(Color.white);
			gutiP3[i].setBounds(x,420,45 ,45);
			frame.getContentPane().add(gutiP3[i]);
		}
		
		
		for(int i = 4, y = 410 ; i >= 0 ; i--, y+=45)
		{
			if(i==0)
			{
				road[i] = new JButton(String.valueOf(i));
				road[i].setBounds(450,y,45,45);
				road[i].setFont(new Font("Arial" , Font.PLAIN, 10));
				road[i].setBackground(Color.yellow);
				frame.getContentPane().add(road[i]);
			}
			else
			{
				road[i] = new JButton(String.valueOf(i));
				road[i].setBounds(450,y,45,45);
				road[i].setFont(new Font("Arial" , Font.PLAIN, 10));
				road[i].setBackground(Color.yellow);
				frame.getContentPane().add(road[i]);
			}
		}
		
		
		//left right
		for(int i = 10, x = 180 ; i >= 5 ; i--, x+=45)
		{
			road [i] = new JButton(String.valueOf(i));
			road [i].setBounds(x,365,45,45);
			road [i].setFont(new Font("Arial" , Font.PLAIN, 9));
			road[i].setBackground(Color.yellow);
			frame.getContentPane().add(road [i]);
			
		}
		
		
		//left middle
		for(int i = 11, x = 180 ; i <= 11 ; i++, x+=45)
		{
		road [i] = new JButton(String.valueOf(i));
		road [i].setBounds(x,320,45,45);
		road [i].setFont(new Font("Arial" , Font.PLAIN, 9));
		road[i].setBackground(Color.yellow);
		frame.getContentPane().add(road [i]);
			
		}
		
		///left left
		for(int i = 12, x = 180 ; i <= 17 ; i++, x+=45)
		{
			if(i==12)
			{
				road [i] = new JButton(String.valueOf(i));
				road [i].setBounds(x,275,45,45);
				road [i].setFont(new Font("Arial" , Font.PLAIN, 9));
				road[i].setBackground(Color.yellow);
				frame.getContentPane().add(road [i]);
			}
			
			/*if(i==13)
			{
				road [i] = new JButton(String.valueOf(i));
				road [i].setBounds(x,275,45,45);
				road [i].setFont(new Font("Arial" , Font.PLAIN, 9));
				road [i].setBackground(Color.LIGHT_GRAY);
				frame.getContentPane().add(road [i]);
			}*/
			else
			{
				road [i] = new JButton(String.valueOf(i));
				road [i].setBounds(x,275,45,45);
				road [i].setFont(new Font("Arial" , Font.PLAIN, 9));
				road [i].setBackground(Color.yellow);
				frame.getContentPane().add(road [i]);
			}
				
			
		}
		
		// left player 1 er finishing ghor ...
		for(int i = 52, x = 225 ; i <= 56 ; i++, x+=45)
		{
			road [i] = new JButton(String.valueOf(i));
			road [i].setBounds(x,320,45,45);
			road [i].setFont(new Font("Arial" , Font.PLAIN, 9));
			road[i].setBackground(Color.yellow);
			frame.getContentPane().add(road [i]);
			
		}
		// player 1 er finishing ghor  ses...
		//up left button
		for(int i = 23, y = 5 ; i >= 18 ; i--, y+=45)
		{
			road[i] = new JButton(String.valueOf(i));
			road[i].setBounds(450,y,45,45);
			road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
			road[i].setBackground(Color.yellow);
			frame.getContentPane().add(road[i]);
			
		}
		
		        // up right player 1 er finishing ghor ...
		for(int i = 62, y = 50 ; i <= 66 ; i++, y+=45)
		{
			road[i] = new JButton(String.valueOf(i));
			road[i].setBounds(495,y,45,45);
			road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
			road[i].setBackground(Color.yellow);
			frame.getContentPane().add(road[i]);
			
		}
		// player 1 er finishing ghor  ses...
		//up middle
				for(int i = 24, y = 5 ; i <= 24 ; i++, y+=45)
				{
					road[i] = new JButton(String.valueOf(i));
					road[i].setBounds(495,y,45,45);
					road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
					road[i].setBackground(Color.yellow);
					frame.getContentPane().add(road[i]);
					
				}
		//upright button
		
		for(int i = 25, y = 5 ; i <= 30 ; i++, y+=45)
		{
			if(i==25)
			{
				road[i] = new JButton(String.valueOf(i));
				road[i].setBounds(540,y,45,45);
				road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
				road[i].setBackground(Color.yellow);
				frame.getContentPane().add(road[i]);
			}
			/*if(i==26)
			{
				road[i] = new JButton(String.valueOf(i));
				road[i].setBounds(540,y,45,45);
				road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
				road[i].setBackground(Color.LIGHT_GRAY);
				frame.getContentPane().add(road[i]);
			}*/
			else
			{
				road[i] = new JButton(String.valueOf(i));
				road[i].setBounds(540,y,45,45);
				road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
				road[i].setBackground(Color.yellow);
				frame.getContentPane().add(road[i]);
			}
			
		}
		
		//right left
		for(int i = 31, x = 585 ; i <= 36 ; i++, x+=45)
		{
			road[i] = new JButton(String.valueOf(i));
			road[i].setBounds(x,275,45,45);
			road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
			road[i].setBackground(Color.yellow);
			frame.getContentPane().add(road[i]);
			
		}
		
		// right player 1 er finishing ghor ...
		for(int i = 56, x = 585 ; i >= 52 ; i--, x+=45)
		{
			road[i] = new JButton(String.valueOf("R"));
			road[i].setBounds(x,320,45,45);
			road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
			road[i].setBackground(Color.yellow);
			frame.getContentPane().add(road[i]);
			
		}
						// player 1 er finishing ghor  ses...
		
		// right middle button
		
		for(int i = 37, x = 810 ; i <= 37 ; i++, x+=45)
		{
			road[i] = new JButton(String.valueOf(i));
			road[i].setBounds(x,320,45,45);
			road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
			road[i].setBackground(Color.yellow);
			frame.getContentPane().add(road[i]);
			
		}
		// right right button
	
		for(int i = 43, x = 585 ; i >= 38 ; i--, x+=45)
		{
			
			   if(i==38)
			      {
				       road[i] = new JButton(String.valueOf(i));
				       road[i].setBounds(x,365,45,45);
				       road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
				       road[i].setBackground(Color.yellow);
				       frame.getContentPane().add(road[i]);
			      }
			   if(i==39)
			         {
				       road[i] = new JButton(String.valueOf(i));
				       road[i].setBounds(x,365,45,45);
				       road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
				       road[i].setBackground(Color.yellow);
				       frame.getContentPane().add(road[i]);
			         }
			else
			{
				road[i] = new JButton(String.valueOf(i));
				road[i].setBounds(x,365,45,45);
				road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
				road[i].setBackground(Color.yellow);
				frame.getContentPane().add(road[i]);
			}
			
			
		}
		
		// bottom Right button
		
		for(int i = 44, y = 410 ; i <= 49 ; i++, y+=45)
		{
			road[i] = new JButton(String.valueOf(i));
			road[i].setBounds(540,y,45,45);
			road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
			road[i].setBackground(Color.yellow);
			frame.getContentPane().add(	road[i]);
			
		}
		///bottom middle
		for(int i = 50, y = 635 ; i <= 50 ; i++, y+=45)
		{
			road[i] = new JButton(String.valueOf(i));
			road[i].setBounds(495,y,45,45);
			road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
			road[i].setBackground(Color.yellow);
			frame.getContentPane().add(road[i]);
			
		}
		
		for(int i = 51, y = 635 ; i <= 51 ; i++, y+=45)
		{
			road[i] = new JButton(String.valueOf(i));
			road[i].setBounds(450,y,45,45);
			road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
			road[i].setBackground(Color.yellow);
			frame.getContentPane().add(road[i]);
			
		}
		
      
		pic.setBounds(500,319,45,45);
		pic.setBackground(Color.black);
		frame.getContentPane().add(pic);
		
		
		
		//gutiP1[i].setBounds(x,420,45 ,45);

		picA.setBounds(170,450,300,300);
		picA.setBackground(Color.black);
		frame.getContentPane().add(picA);
		
		
		
		
		picB.setBounds(640,40,200,200);
		picB.setBackground(Color.black);
		frame.getContentPane().add(picB);
		
		

		picC.setBounds(5,480,200,200);
		picC.setBackground(Color.black);
		frame.getContentPane().add(picC);
		
		
		
		
		
		
		// bottom player 1 er finishing ghor ...
		for(int i = 56, y = 410 ; i >= 52 ; i--, y+=45)
		{
			road[i] = new JButton(String.valueOf(i));
			road[i].setBounds(495,y,45,45);
			road[i].setFont(new Font("Arial" , Font.PLAIN, 9));
			road[i].setBackground(Color.yellow);
			frame.getContentPane().add(	road[i]);
			
		}
		// player 1 er finishing ghor  ses...
	}
	
	public void initial() 
	{
		frame = new JFrame("Ludu Game");
		frame.setBounds(100, 100, 885, 725);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(Color.green);
		frame.setVisible(true);
		frame.getContentPane().setLayout(null);
		panel = new JPanel();
		panel.setBounds(150,0,745,695);
		panel.setBackground(new Color(26, 26, 100));
		
	
		
		setupRoad();
		
		frame.getContentPane().add(panel);
		label1 = new JLabel(str111);
		label1.setBounds(20,100,100,30);
		label1.setFont(new Font("Arial" , Font.BOLD, 16));
		label1.setForeground(Color.black);
		frame.getContentPane().add(label1);
		
		
		label2 = new JLabel(str222);
		label2.setBounds(20,200,100,30);
		label2.setFont(new Font("Arial" , Font.BOLD, 16));
		label2.setForeground(Color.black);
	    frame.getContentPane().add(label2);
	    
	    
	    
		frame.getContentPane().add(panel);
		label3 = new JLabel(str333);
		label3.setBounds(20,300,100,30);
		label3.setFont(new Font("Arial" , Font.BOLD, 16));
		label3.setForeground(Color.black);
		frame.getContentPane().add(label3);
		
		
		label4 = new JLabel(str444);
		label4.setBounds(20,400,100,30);
		label4.setFont(new Font("Arial" , Font.BOLD, 16));
		label4.setForeground(Color.black);
	    frame.getContentPane().add(label4);
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
		play1 = new JButton(" Player : A  ");
		play1.setBounds(20,50,100,30);

		
		play2 = new JButton("Player : B");
		play2.setBounds(20,150,100,30);
		
		play3 = new JButton(" Player : C");
		play3.setBounds(20,250,100,30);
		
		play4 = new JButton(" Player : D");
		play4.setBounds(20,350,100,30);
		
		
		frame.getContentPane().add(play1);
		frame.getContentPane().add(play2);

		frame.getContentPane().add(play3);
		frame.getContentPane().add(play4);
		
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setResizable(false);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
	}
	
	public static void main(String args[])
	{
		Ludo obj = new Ludo();
	}
}

